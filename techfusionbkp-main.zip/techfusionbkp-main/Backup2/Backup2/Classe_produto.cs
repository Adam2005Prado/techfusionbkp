﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backup2
{
    public class Classe_produto
    {

       public string nome;
       public Image imagem;
       public string quantidade;
        public float preco;
        public float preco2;
       
        public Classe_produto() 
        { 
            
        }

    }


}
